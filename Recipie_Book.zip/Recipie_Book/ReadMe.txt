# 🍲 Recipe Book Web Application

A fully functional and visually appealing **Recipe Book** built using **HTML**, **CSS**, and **JavaScript**. This application allows users to add, view, and search for recipes — with data saved in the browser's local storage for persistence across sessions.

## 🚀 Features

- **Add Recipes**  
  Users can input recipe name, ingredients, preparation steps, and upload an image.

- **View Recipes**  
  Recipes are displayed in a clean, card-based layout.

- **Search Functionality**  
  Search for recipes by name or ingredients with instant filtering.

- **Data Persistence**  
  Recipes are stored using `localStorage`, so they remain available even after the page is refreshed or reopened.

## 🛠️ Technologies Used

- **HTML5** – For creating the structure and layout.
- **CSS3** – For styling and responsive design.
- **JavaScript (Vanilla)** – For DOM manipulation, form handling, and local storage.

## 📁 Project Structure

