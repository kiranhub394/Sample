let recipes = JSON.parse(localStorage.getItem('recipes')) || [];

function displayRecipes(filtered = recipes) {
    const container = document.getElementById('recipes');
    container.innerHTML = '';
    filtered.forEach((recipe, index) => {
        const card = document.createElement('div');
        card.className = 'recipe-card';
        card.innerHTML = `
            <h3>${recipe.name}</h3>
            <img src="${recipe.image}" alt="${recipe.name}" />
            <p><strong>Ingredients:</strong><br>${recipe.ingredients}</p>
            <p><strong>Steps:</strong><br>${recipe.steps}</p>
        `;
        container.appendChild(card);
    });
}

document.getElementById('recipe-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const ingredients = document.getElementById('ingredients').value.trim();
    const steps = document.getElementById('steps').value.trim();
    const imageInput = document.getElementById('image');

    if (!name || !ingredients || !steps) {
        alert('Please fill all fields.');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(event) {
        const recipe = {
            name,
            ingredients,
            steps,
            image: event.target.result || ''
        };
        recipes.push(recipe);
        localStorage.setItem('recipes', JSON.stringify(recipes));
        displayRecipes();
        document.getElementById('recipe-form').reset();
    };

    if (imageInput.files[0]) {
        reader.readAsDataURL(imageInput.files[0]);
    } else {
        reader.onload({ target: { result: '' }});
    }
});

document.getElementById('search').addEventListener('input', function(e) {
    const query = e.target.value.toLowerCase();
    const filtered = recipes.filter(recipe =>
        recipe.name.toLowerCase().includes(query) ||
        recipe.ingredients.toLowerCase().includes(query)
    );
    displayRecipes(filtered);
});

displayRecipes();