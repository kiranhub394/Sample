# Weather App 🌤️

## Description
A simple web app that fetches and displays current weather info for a given city using the OpenWeatherMap API.

## Features
- City-based weather search
- Temperature, weather icon, and description
- Error handling
- Responsive and user-friendly design

## Setup Instructions
1. Clone/download the project.
2. Replace `'YOUR_API_KEY_HERE'` in `script.js` with your OpenWeatherMap API key.
3. Open `index.html` in your browser.
